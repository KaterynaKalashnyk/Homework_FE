// Напишите функцию, max_number,
//  которая принимает два аргумента с числовым значением и возвращает большее значение.

function max_number(a, b){
    if(a < b){
        console.log(b)
    }else{
        console.log(a)
    }
}