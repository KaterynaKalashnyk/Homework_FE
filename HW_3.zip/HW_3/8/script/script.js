// В программе задана переменная n. Напишите программу, 
// которая с помощью цикла считает сумму чисел от 1 до n и выводит в консоль.

function rechnen (n){
    result = 0;
    for(i = 1; i < n; i++){
        result += i
    }
    return result
}
console.log(rechnen (15))