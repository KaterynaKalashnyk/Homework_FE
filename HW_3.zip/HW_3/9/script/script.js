// Напишите функцию power, 
// которая в качестве аргумента n принимает число и возвращает квадрат этого числа.

function power(n){
    result = n**2
    return result
}
console.log(power(8))