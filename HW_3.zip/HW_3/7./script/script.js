// В программе заданы две переменные n и m с числовым значением каждая. 
// Напишите цикл, который считает сумму четных чисел и нечетных чисел от n до m. 
// Суммы выведите в консоль (в начале сумму четных чисел, а затем сумму нечетных). 
// Я не поняла этого задания и к сожалению мне не удалось её сделать  

function rechnen (a, b){
    let result = 0;
    for (i = a; i < (b + 1) % 2 == 0; i++){
        result += i 
    }
    return result 
}
function rechnen_2 (a, b){
    result2 = 0
    for(i = a; i < b + 1 % 2; i++){
        result2 +=i
    }
    return result2
}
console.log(rechnen (12, 19));
console.log(rechnen_2(12, 19));